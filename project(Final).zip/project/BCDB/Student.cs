﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace BCDB
{
    class Student
    {
        int sNumber;
        string sName;
        Image sImage;
        string dateOfBirth;
        string gender;
        string phone;
        string address;
        string moduleCodes;

        public Student() 
        {
        
        }

        public Student(int sNumber, string sName, Image sImage, string dateOfBirth, string gender, string phone, string address, string moduleCodes)
        {
            this.sNumber = sNumber;
            this.sName = sName;
            this.sImage = sImage;
            this.dateOfBirth = dateOfBirth;
            this.gender = gender;
            this.phone = phone;
            this.address = address;
            this.moduleCodes = moduleCodes;
        }

        public int SNumber { get => sNumber; set => sNumber = value; }
        public string SName { get => sName; set => sName = value; }
        public Image SImage { get => sImage; set => sImage = value; }
        public string DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Address { get => address; set => address = value; }
        public string ModuleCodes { get => moduleCodes; set => moduleCodes = value; }
    }
}
