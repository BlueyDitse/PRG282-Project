﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BCDB
{
    class Module
    {
        string mCode;
        string mName;
        string mDescription;
        string mResource;

        public Module(string mCode, string mName, string mDescription, string mResource)
        {
            this.mCode = mCode;
            this.mName = mName;
            this.mDescription = mDescription;
            this.mResource = mResource;
        }

        public Module() { }

        public string MCode { get => mCode; set => mCode = value; }
        public string MName { get => mName; set => mName = value; }
        public string MDescription { get => mDescription; set => mDescription = value; }
        public string MResource { get => mResource; set => mResource = value; }
    }
}
