﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        datahandler handler = new datahandler();
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            handler.addStudent(int.Parse(textBox8.Text), textBox7.Text,textBox6.Text, textBox5.Text, textBox10.Text, textBox9.Text );
            MessageBox.Show("Data inserted Successfully");
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            handler.DeleteStudent(int.Parse(textBox8.Text));
            MessageBox.Show("Data delete Successfully");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            handler.UpdateStudent(int.Parse(textBox8.Text), textBox7.Text, textBox6.Text, textBox5.Text, textBox10.Text, textBox9.Text);
            MessageBox.Show("Data updated Successfully");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            handler.addModule(int.Parse(textBox2.Text), textBox1.Text, textBox3.Text, textBox4.Text  );
            MessageBox.Show("Data inserted Successfully");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            handler.DeleteModule(int.Parse(textBox2.Text));
            MessageBox.Show("Data deleted Successfully");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            handler.UpdateModule(int.Parse(textBox2.Text), textBox1.Text, textBox3.Text, textBox4.Text);
            MessageBox.Show("Data updated Successfully");
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
