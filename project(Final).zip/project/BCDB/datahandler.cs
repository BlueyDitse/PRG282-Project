﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace BCDB
{
    class datahandler
    {
        public datahandler() { }
        string connect = @"Data Source = DESKTOP - L58GKO6; Initial Catalog = BCDB; Integrated Security = True";


        SqlConnection connection;
        SqlCommand command;
        SqlDataReader reader;

        Student aStudent = new Student();
        Module aModule = new Module();


        public void addStudent(int sNumber, string sName, Image sImage, string dateOfBirth, string gender, string phone, string address, string mcodes)
        {
            string myquery = @"INSERT 
                             INTO Students  
                             VALUES ( '" + sNumber + "', '" + sName + "', '" + sImage + "', '" + dateOfBirth + "' , '" + gender + "','"+ phone +"','"+ address + "', '" + mcodes + "')";

            connection = new SqlConnection(connect);
            connection.Open();

            command = new SqlCommand(myquery, connection);

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("New Student has been added :)");
                DisplayData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Student could not be saved: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }


        public void addModule(int mcode, string mname, string mdescription, string resource)
        {
            string myquery = @"INSERT 
                             INTO modules  
                             VALUES ( '" + mcode + "', '" + mname + "', '" + mdescription + "', '" + resource + "')";

            connection = new SqlConnection(connect);
            connection.Open();

            command = new SqlCommand(myquery, connection);

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("New Student has been added :)");
                DisplayData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Student could not be saved: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }


        public void DeleteStudent(int sNumber)
        {
            string query = @"DELETE FROM Students WHERE Student Number = ('" + sNumber + "')";

            connection = new SqlConnection(connect);

            connection.Open();

            command = new SqlCommand(query, connection);

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Deleted Student with ID: " + sNumber);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }


        public void DeleteModule(int code)
        {
            string query = @"DELETE FROM modules WHERE code = ('" + code + "')";

            connection = new SqlConnection(connect);

            connection.Open();

            command = new SqlCommand(query, connection);

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Deleted module with code: " + code);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }


        public void UpdateStudent(int sNumber, string sName, Image sImage, string dateOfBirth, string gender, string phone, string address, string mcodes)
        {
            string query = @"UPDATE Students SET Student Number = ('" + sNumber + "'), Name Surname = ('" + sName + "'), Student Image = ('" + sImage + "'), Date of Birth = ('" + dateOfBirth + "'), gender = ('" + gender + "'), phone = ('"phone"'), address = ('"address"'), module codes = ('"mcodes"') WHERE Stuedent Number = ('" + sNumber + "')";

            connection = new SqlConnection(connect);
            connection.Open();
            command = new SqlCommand(query, connection);

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Details updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public void UpdateModule(int code, string name, string description, string resource)
        {
            string query = @"UPDATE modules SET code = ('" + code + "'), name = ('" + name + "'), description = ('" + description + "'), resource = ('" + resource + "'))";

            connection = new SqlConnection(connect);
            connection.Open();
            command = new SqlCommand(query, connection);

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Details updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public List<Student> SearchStudent(int sNumber)
        {


            string query = @"SELECT * FROM Students WHERE Student Number = ('" + sNumber + "')";


            connection = new SqlConnection(connect);

            connection.Open();

            command = new SqlCommand(query, connection);
            List<Student> theseStudents = new List<Student>();

            try
            {

                reader = command.ExecuteReader();
                if (reader.Read())
                {

                    aStudent.SNumber = reader.GetInt32(0);
                    aStudent.SName = reader[1].ToString();
                    // How to get Image?
                    // aStudent.SImage = ;
                    aStudent.DateOfBirth = reader[2].ToString();
                    aStudent.Gender = reader[3].ToString();
                    aStudent.Phone = reader[4].ToString();
                    aStudent.Address = reader[5].ToString();
                    aStudent.ModuleCodes = reader[6].ToString();

                    // aStudent.ClientID1 = reader.GetInt32(0);
                    //// reader.GetInt32(0);.Name1 = reader[1].ToString();
                    //// aClient.Surname1 = reader[2].ToString();
                    //  aClient.ProductID1 = reader[3].ToString();
                    // aClient.ClientLevel1 = reader.GetInt32(4);

                    theseStudents.Add(new Student(aStudent.SNumber, aStudent.SName, aStudent.SImage, aStudent.DateOfBirth, aStudent.Gender, aStudent.Phone, aStudent.Address, aStudent.ModuleCodes));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return theseStudents;
        }


        public List<Student> SearchModule(int sNumber)
        {


            string query = @"SELECT * FROM Students WHERE Student Number = ('" + sNumber + "')";


            connection = new SqlConnection(connect);

            connection.Open();

            command = new SqlCommand(query, connection);
            List <Module> theseModules = new List<Module>();

            try
            {

                reader = command.ExecuteReader();
                if (reader.Read())
                {

                    aStudent.SNumber = reader.GetInt32(0);
                    aStudent.SName = reader[1].ToString();
                    aStudent.DateOfBirth = reader[2].ToString();
                    aStudent.Gender = reader[3].ToString();
                    aStudent.Phone = reader[4].ToString();
                    aStudent.Address = reader[5].ToString();
                    aStudent.ModuleCodes = reader[6].ToString();


                    theseModules.Add(new Module(aModule.MCode, aModule.MName, aModule.MDescription, aModule.MResource));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return theseModules;
        }

        void DisplayData()
        {
            // Buns any way to get this working?

            SqlCommand query = new SqlCommand("SELECT * FROM tblClients", connection);
            SqlDataAdapter dongle = new SqlDataAdapter(query);

            DataTable dtable = new DataTable();

            dongle.Fill(dtable);
            //customDataView.Datasource = dtable;




        }
    }
}
